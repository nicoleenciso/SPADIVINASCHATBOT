<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Bienvenidos | DIVINAS SPA</title>
    <style>
        body { 
            background: #fff0f5; 
            font-family: 'Comic Sans MS', cursive; 
            display: flex; justify-content: center; align-items: center; 
            height: 100vh; margin: 0; 
        }
        .container { 
            background: white; padding: 60px; border-radius: 60px; 
            border: 10px double #ffb6c1; text-align: center; 
            box-shadow: 0 20px 50px rgba(255,182,193,0.5); 
        }
        h1 { color: #ff1493; font-size: 4.5em; margin: 0; }
        p { color: #db7093; font-size: 1.5em; margin-bottom: 30px; }
        .btn-enter { 
            background: #ff69b4; color: white; padding: 20px 50px; 
            border-radius: 40px; text-decoration: none; font-weight: bold; 
            font-size: 1.5em; display: inline-block; transition: 0.4s;
            box-shadow: 0 8px 0 #db7093;
        }
        .btn-enter:hover { transform: scale(1.05); background: #ff1493; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🌸 DIVINAS ✨</h1>
        <p>Donde la belleza se encuentra con el paraíso.</p>
        <a href="login.jsp" class="btn-enter">Entrar al Spa 💖</a>
    </div>
</body>
</html>