package com.divinas.beans;

import java.io.Serializable;
import java.sql.*;
import java.util.*;
import javax.naming.*;
import javax.sql.DataSource;

public class SpaBean implements Serializable {

    public static class Cita implements Serializable {
        private int id;
        private String clienta, empleada, servicio, hora, estado;

        public Cita(int id, String clienta, String empleada, String servicio, String hora, String estado) {
            this.id = id; this.clienta = clienta; this.empleada = empleada;
            this.servicio = servicio; this.hora = hora; this.estado = estado;
        }
        public int getId() { return id; }
        public String getClienta() { return clienta; }
        public String getEmpleada() { return empleada; }
        public String getServicio() { return servicio; }
        public String getHora() { return hora; }
        public String getEstado() { return estado; }
    }

    // Conexión JNDI
    private Connection con() throws Exception {
        Context initContext = new InitialContext();
        DataSource ds = (DataSource) initContext.lookup("java:comp/env/jdbc/myDatasource");
        return ds.getConnection();
    }

    // MÉTODO CORREGIDO: registrarUsuario (Ahora acepta el ROL)
    public boolean registrarUsuario(String u, String p, String n, String rol) {
        String sql = "INSERT INTO usuarios (username, password, nombre_completo, rol) VALUES (?,?,?,?)";
        try (Connection c = con(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, u);
            ps.setString(2, p);
            ps.setString(3, n);
            ps.setString(4, rol);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public Map<Integer, String> getListaServicios() {
        Map<Integer, String> servicios = new LinkedHashMap<>();
        try (Connection c = con(); Statement st = c.createStatement(); 
             ResultSet rs = st.executeQuery("SELECT id, nombre FROM servicios ORDER BY nombre ASC")) {
            while(rs.next()) {
                servicios.put(rs.getInt("id"), rs.getString("nombre"));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return servicios;
    }

    public Map<String, String> getListaEmpleadas() {
        Map<String, String> empleadas = new LinkedHashMap<>();
        try (Connection c = con(); Statement st = c.createStatement(); 
             ResultSet rs = st.executeQuery("SELECT username, nombre_completo FROM usuarios WHERE rol='empleada'")) {
            while(rs.next()) {
                empleadas.put(rs.getString("username"), rs.getString("nombre_completo"));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return empleadas;
    }

    public void agendar(String clienta, String servId, String empUser, String hora) {
        String sql = "INSERT INTO citas (clienta_user, servicio_id, empleada_user, fecha, hora, estado) VALUES (?,?,?,CURDATE(),?,'Agendada')";
        try (Connection c = con(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, clienta);
            ps.setInt(2, Integer.parseInt(servId));
            ps.setString(3, empUser);
            ps.setString(4, hora);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void setEstado(String id, String est) {
        try (Connection c = con(); PreparedStatement ps = c.prepareStatement("UPDATE citas SET estado=? WHERE id=?")) {
            ps.setString(1, est);
            ps.setInt(2, Integer.parseInt(id));
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public List<Cita> getCitas(String rol, String user) {
        List<Cita> lista = new ArrayList<>();
        String sql = "SELECT c.id, u.nombre_completo as cli, e.nombre_completo as emp, s.nombre, c.hora, c.estado " +
                     "FROM citas c " +
                     "JOIN servicios s ON c.servicio_id = s.id " +
                     "JOIN usuarios u ON c.clienta_user = u.username " +
                     "LEFT JOIN usuarios e ON c.empleada_user = e.username ";
        
        if("clienta".equals(rol)) sql += " WHERE c.clienta_user = ?";
        else if("empleada".equals(rol)) sql += " WHERE c.empleada_user = ?";
        sql += " ORDER BY c.hora ASC";

        try (Connection c = con(); PreparedStatement ps = c.prepareStatement(sql)) {
            if(!"gerente".equals(rol)) ps.setString(1, user);
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                lista.add(new Cita(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6)));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return lista;
    }
}